"""
medgemma_subcall.py

Sub-call reasoning model wrapper for Recursive Medical Language Model (R-MedLM)

This model is used for:
- Patient-level analysis
- Lab/vitals trajectory interpretation
- Clinical note summarization
- Any focused reasoning on small context slices
"""

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
import yaml


class MedGemmaSubcall:
    def __init__(self, config_path="config/model_config.yaml"):
        self.config = self._load_config(config_path)
        self.model_name = self.config["subcall_model"]["name"]
        self.device = "cuda" if torch.cuda.is_available() else "cpu"

        print(f"[MedGemmaSubcall] Loading model: {self.model_name} on {self.device}")

        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_name,
            torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
            device_map="auto"
        )

        self.model.eval()

    def _load_config(self, path):
        with open(path, "r") as f:
            return yaml.safe_load(f)

    def generate(self, prompt, max_new_tokens=256, temperature=0.1):
        """
        Generates focused clinical reasoning output.
        Lower temperature for more deterministic medical reasoning.
        """
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)

        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id
            )

        decoded = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return decoded[len(prompt):].strip()
