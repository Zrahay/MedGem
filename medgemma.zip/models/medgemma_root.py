"""
medgemma_root.py

Root planner model wrapper for Recursive Medical Language Model (R-MedLM)

This model is responsible for:
- Reading system + tool instructions
- Writing Python code to explore MIMIC memory
- Planning recursive sub-calls
- Building the final answer via variables in the REPL
"""

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from pathlib import Path
import yaml


class MedGemmaRoot:
    def __init__(self, config_path="config/model_config.yaml"):
        self.config = self._load_config(config_path)
        self.model_name = self.config["root_model"]["name"]
        self.device = "cuda" if torch.cuda.is_available() else "cpu"

        print(f"[MedGemmaRoot] Loading model: {self.model_name} on {self.device}")

        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_name,
            torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
            device_map="auto"
        )

        self.model.eval()

    def _load_config(self, path):
        with open(path, "r") as f:
            return yaml.safe_load(f)

    def generate(self, prompt, max_new_tokens=512, temperature=0.2):
        """
        Generates code or reasoning text from the root planner.
        """
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)

        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id
            )

        decoded = self.tokenizer.decode(outputs[0], skip_special_tokens=True)

        # Remove the original prompt from output
        return decoded[len(prompt):].strip()